package com.pocketboost;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class ClientOptimizer {
    private static final int MAX_LEVEL = 4;
    public static volatile boolean openGui = false;
    private final Minecraft mc = Minecraft.getMinecraft();
    private final KeyBinding openKey = new KeyBinding("Abrir menu PocketBoost", Keyboard.KEY_P, "PocketBoost");

    private boolean baselineCaptured;
    private int baseRender, baseParticles, baseClouds, baseAo;
    private boolean baseShadows, baseFancy;
    private int level, tick, goodSamples, badSamples, cooldown;

    public ClientOptimizer() { ClientRegistry.registerKeyBinding(openKey); }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (openKey.isPressed()) openGui = true;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (openGui && mc.player != null) {
            openGui = false;
            mc.displayGuiScreen(new PBGui(mc.currentScreen));
        }
        if (mc.world == null || mc.player == null) return;

        if (PBConfig.baseTweaks && !PBConfig.tweaksApplied) applyBaseTweaks();
        if (!PBConfig.adaptive) {
            if (level > 0) restoreBaseline();
            return;
        }
        if (!baselineCaptured) captureBaseline();
        if (++tick < PBConfig.sampleTicks) return;
        tick = 0;
        if (mc.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }

        int fps = Minecraft.getDebugFPS();
        if (fps < PBConfig.targetFps - 3) {
            goodSamples = 0;
            if (++badSamples >= 2 && level < MAX_LEVEL) { level++; badSamples = 0; applyLevel(); }
        } else if (fps > PBConfig.targetFps + 15) {
            badSamples = 0;
            if (++goodSamples >= 4 && level > 0) { level--; goodSamples = 0; applyLevel(); }
        } else {
            badSamples = 0;
            goodSamples = 0;
        }
    }

    private void captureBaseline() {
        GameSettings gs = mc.gameSettings;
        baseRender = gs.renderDistanceChunks;
        baseParticles = gs.particleSetting;
        baseClouds = gs.clouds;
        baseShadows = gs.entityShadows;
        baseAo = gs.ambientOcclusion;
        baseFancy = gs.fancyGraphics;
        baselineCaptured = true;
    }

    private void applyLevel() {
        if (!baselineCaptured) captureBaseline();
        GameSettings gs = mc.gameSettings;
        int rd = baseRender, pt = baseParticles, cl = baseClouds;
        boolean shadows = baseShadows;
        if (level >= 1) { pt = Math.max(pt, 1); shadows = false; }
        if (level >= 2) { cl = 0; rd = Math.min(rd, Math.max(PBConfig.minRenderDistance, 8)); }
        if (level >= 3) { pt = 2; rd = Math.min(rd, Math.max(PBConfig.minRenderDistance, 6)); }
        if (level >= 4) rd = Math.min(rd, Math.max(PBConfig.minRenderDistance, 4));
        boolean renderChanged = gs.renderDistanceChunks != rd;
        gs.particleSetting = pt;
        gs.entityShadows = shadows;
        gs.clouds = cl;
        gs.renderDistanceChunks = rd;
        if (renderChanged && mc.renderGlobal != null) mc.renderGlobal.loadRenderers();
        cooldown = 2;
    }

    private void restoreBaseline() {
        if (!baselineCaptured || mc.gameSettings == null) return;
        GameSettings gs = mc.gameSettings;
        boolean renderChanged = gs.renderDistanceChunks != baseRender;
        gs.renderDistanceChunks = baseRender;
        gs.particleSetting = baseParticles;
        gs.clouds = baseClouds;
        gs.entityShadows = baseShadows;
        level = tick = goodSamples = badSamples = cooldown = 0;
        if (renderChanged && mc.renderGlobal != null) mc.renderGlobal.loadRenderers();
    }

    private void applyBaseTweaks() {
        GameSettings gs = mc.gameSettings;
        gs.clouds = 0;
        gs.entityShadows = false;
        gs.ambientOcclusion = 1;
        gs.useVbo = true;
        gs.enableVsync = false;
        gs.fancyGraphics = false;
        gs.saveOptions();
        PBConfig.markApplied();
        if (mc.renderGlobal != null) mc.renderGlobal.loadRenderers();
        baselineCaptured = false;
    }

    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Pre<?> event) {
        if (!PBConfig.entityCull || mc.world == null) return;
        Entity view = mc.getRenderViewEntity();
        if (view == null) return;
        Entity ent = event.getEntity();
        // Nunca esconder jogadores, incluindo outros jogadores em LAN/servidores.
        if (ent == view || ent instanceof EntityPlayer || !(ent instanceof EntityLiving)) return;
        if (!ent.isNonBoss()) return;
        double distance = PBConfig.cullDistance;
        if (ent.getDistanceSq(view) > distance * distance) event.setCanceled(true);
    }
}
