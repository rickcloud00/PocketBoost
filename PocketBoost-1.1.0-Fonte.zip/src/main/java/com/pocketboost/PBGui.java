package com.pocketboost;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class PBGui extends GuiScreen {
    private static final int[] FPS = {30, 40, 50, 60, 90};
    private static final int[] CULL = {24, 40, 64, 96, 128};
    private static final int[] MINRD = {2, 3, 4, 6, 8};
    private static final int[] THR = {32, 48, 64, 96};
    private static final int[] INTERVAL = {2, 3, 4, 6, 8};
    private static final int[] ITEMS = {0, 100, 250, 500, 1000};

    private final GuiScreen parent;
    private GuiButton bAdaptive, bFps, bCull, bCullDist, bThrottle, bThrDist;
    private GuiButton bMinRd, bInterval, bItems, bTweaks;

    public PBGui(GuiScreen parent) { this.parent = parent; }

    @Override
    public void initGui() {
        buttonList.clear();
        int w = 148, h = 20, gap = 4;
        int lx = this.width / 2 - w - 3, rx = this.width / 2 + 3;
        int y = Math.max(28, this.height / 2 - 68);
        bAdaptive = add(0, lx, y, w, h); bFps = add(1, rx, y, w, h); y += h + gap;
        bCull = add(2, lx, y, w, h); bCullDist = add(3, rx, y, w, h); y += h + gap;
        bThrottle = add(4, lx, y, w, h); bThrDist = add(5, rx, y, w, h); y += h + gap;
        bMinRd = add(6, lx, y, w, h); bInterval = add(8, rx, y, w, h); y += h + gap;
        bItems = add(9, lx, y, w, h); bTweaks = add(7, rx, y, w, h); y += h + gap + 4;
        buttonList.add(new GuiButton(10, this.width / 2 - 100, y, 200, 20, "Salvar e fechar"));
        refresh();
    }

    private GuiButton add(int id, int x, int y, int w, int h) {
        GuiButton b = new GuiButton(id, x, y, w, h, ""); buttonList.add(b); return b;
    }
    private static String onOff(boolean v) { return v ? "ON" : "OFF"; }
    private static int next(int cur, int[] opts) {
        for (int o : opts) if (o > cur) return o;
        return opts[0];
    }
    private void refresh() {
        bAdaptive.displayString = "FPS adaptativo: " + onOff(PBConfig.adaptive);
        bFps.displayString = "Meta FPS: " + PBConfig.targetFps;
        bCull.displayString = "Ocultar criaturas: " + onOff(PBConfig.entityCull);
        bCullDist.displayString = "Distancia criaturas: " + PBConfig.cullDistance;
        bThrottle.displayString = "IA economica: " + onOff(PBConfig.serverThrottle);
        bThrDist.displayString = "Distancia IA: " + PBConfig.throttleDistance;
        bMinRd.displayString = "Render minimo: " + PBConfig.minRenderDistance;
        bInterval.displayString = "Intervalo IA: " + PBConfig.throttleInterval;
        bItems.displayString = "Limite itens: " + (PBConfig.itemLimit == 0 ? "OFF" : PBConfig.itemLimit);
        bTweaks.displayString = "Reaplicar ajustes base";
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        switch (b.id) {
            case 0: PBConfig.adaptive = !PBConfig.adaptive; break;
            case 1: PBConfig.targetFps = next(PBConfig.targetFps, FPS); break;
            case 2: PBConfig.entityCull = !PBConfig.entityCull; break;
            case 3: PBConfig.cullDistance = next(PBConfig.cullDistance, CULL); break;
            case 4: PBConfig.serverThrottle = !PBConfig.serverThrottle; break;
            case 5: PBConfig.throttleDistance = next(PBConfig.throttleDistance, THR); break;
            case 6: PBConfig.minRenderDistance = next(PBConfig.minRenderDistance, MINRD); break;
            case 7: PBConfig.baseTweaks = true; PBConfig.tweaksApplied = false; break;
            case 8: PBConfig.throttleInterval = next(PBConfig.throttleInterval, INTERVAL); break;
            case 9: PBConfig.itemLimit = next(PBConfig.itemLimit, ITEMS); break;
            case 10:
                PBConfig.saveAll();
                this.mc.displayGuiScreen(parent);
                return;
            default: return;
        }
        PBConfig.saveAll();
        refresh();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, "PocketBoost 1.1 - Configuracoes", width / 2, Math.max(10, height / 2 - 90), 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override public boolean doesGuiPauseGame() { return false; }
}
