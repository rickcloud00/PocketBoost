package com.pocketboost;

import java.util.Collections;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;

public class PBCommand extends CommandBase {
    @Override
    public String getName() {
        return "pocketboost";
    }

    @Override
    public List<String> getAliases() {
        return Collections.singletonList("pb");
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/pocketboost";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }

    @Override
    public boolean checkPermission(MinecraftServer server, ICommandSender sender) {
        return true;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
        ClientOptimizer.openGui = true;
    }
}
