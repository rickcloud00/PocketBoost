package com.pocketboost;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = PocketBoost.MODID, name = "PocketBoost", version = PocketBoost.VERSION,
        acceptedMinecraftVersions = "[1.12.2]", acceptableRemoteVersions = "*")
public class PocketBoost {
    public static final String MODID = "pocketboost";
    public static final String VERSION = "1.1.0";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        PBConfig.load(event.getSuggestedConfigurationFile());
        MinecraftForge.EVENT_BUS.register(new ServerOptimizer());
        if (event.getSide() == Side.CLIENT) {
            MinecraftForge.EVENT_BUS.register(new ClientOptimizer());
            net.minecraftforge.client.ClientCommandHandler.instance.registerCommand(new PBCommand());
        }
    }
}
