# PocketBoost 1.1.0 — Forge 1.12.2

Mod de ajustes gráficos adaptativos para Minecraft Java 1.12.2, com foco em celulares e launchers Java para Android.

## Requisitos
- Minecraft 1.12.2
- Minecraft Forge 14.23.5.2860
- Java 8 para compilar

## Compilar pelo GitHub (inclusive pelo celular)
1. Crie um repositório no GitHub e envie o conteúdo desta pasta mantendo a estrutura de diretórios.
2. Abra a aba **Actions** e execute **Build PocketBoost 1.1** (ou faça um push).
3. Ao terminar, baixe o artefato `PocketBoost-1.1.0-Forge-1.12.2`.
4. Extraia o ZIP e coloque `PocketBoost-1.1.0.jar` na pasta `mods` da instalação Forge 1.12.2.

## Controles
- Tecla **P**: abre o menu. Também pode usar `/pb`.
- FPS adaptativo: ajusta partículas, sombras, nuvens e distância de renderização em etapas.
- Ocultar criaturas: efeito apenas visual e nunca oculta jogadores.
- IA econômica: opcional e desligada por padrão; afeta somente animais passivos distantes e pode alterar seus comportamentos.
- Limite de itens: opcional e desligado por padrão. Quando ativado, remove itens antigos do chão acima do limite por mundo.

Configurações ficam em `config/pocketboost.cfg`.

## Observações
PocketBoost não garante aumento de FPS em todos os aparelhos. O resultado depende do dispositivo, da versão do launcher, dos demais mods e do mundo. A compilação deve ser validada no GitHub Actions e o JAR testado no jogo.
