package com.pocketboost;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ServerOptimizer {
    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent e) {
        if (!PBConfig.serverThrottle) return;
        EntityLivingBase base = e.getEntityLiving();
        if (base.world.isRemote || !(base instanceof EntityAnimal) || !(base instanceof EntityLiving)) return;
        EntityLiving ent = (EntityLiving) base;
        // Somente animais passivos, sem combate, domesticação, montaria ou coleira.
        if (!ent.isNonBoss() || ent.isBeingRidden() || ent.isRiding()) return;
        if (ent instanceof EntityTameable && ((EntityTameable) ent).isTamed()) return;
        if (ent.getLeashed() || ent.hurtTime > 0 || ent.getAttackTarget() != null) return;
        if (ent.world.getClosestPlayerToEntity(ent, PBConfig.throttleDistance) != null) return;
        if (ent.ticksExisted % PBConfig.throttleInterval != 0) e.setCanceled(true);
    }

    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.world.isRemote || PBConfig.itemLimit <= 0) return;
        if (e.world.getTotalWorldTime() % 100 != 0) return;
        List<EntityItem> items = new ArrayList<EntityItem>();
        for (Entity ent : new ArrayList<Entity>(e.world.loadedEntityList)) {
            if (ent instanceof EntityItem && !ent.isDead) items.add((EntityItem) ent);
        }
        int excess = items.size() - PBConfig.itemLimit;
        if (excess <= 0) return;
        Collections.sort(items, new Comparator<EntityItem>() {
            @Override public int compare(EntityItem a, EntityItem b) {
                return Integer.compare(b.ticksExisted, a.ticksExisted); // mais antigos primeiro
            }
        });
        for (int i = 0; i < excess; i++) items.get(i).setDead();
    }
}
