package com.pocketboost;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

public final class PBConfig {
    private static Configuration cfg;
    public static boolean adaptive, entityCull, serverThrottle, baseTweaks, tweaksApplied;
    public static int targetFps, sampleTicks, minRenderDistance, cullDistance;
    public static int throttleDistance, throttleInterval, itemLimit;

    private PBConfig() { }

    public static void load(File file) {
        cfg = new Configuration(file);
        sync();
    }

    private static void sync() {
        String c = "client";
        baseTweaks = cfg.getBoolean("baseTweaks", c, true, "Aplica ajustes graficos leves uma unica vez.");
        tweaksApplied = cfg.getBoolean("tweaksApplied", c, false, "Controle interno dos ajustes base.");
        adaptive = cfg.getBoolean("adaptive", c, true, "Ajusta a qualidade para aproximar-se do FPS alvo.");
        targetFps = cfg.getInt("targetFps", c, 40, 15, 120, "FPS alvo do modo adaptativo.");
        sampleTicks = cfg.getInt("sampleTicks", c, 60, 20, 400, "Intervalo de amostragem em ticks.");
        minRenderDistance = cfg.getInt("minRenderDistance", c, 3, 2, 16, "Distancia minima usada pelo modo adaptativo.");
        entityCull = cfg.getBoolean("entityCull", c, true, "Oculta visualmente criaturas distantes; nao afeta jogadores.");
        cullDistance = cfg.getInt("cullDistance", c, 40, 8, 256, "Distancia em blocos para ocultar criaturas.");

        String s = "server";
        serverThrottle = cfg.getBoolean("serverThrottle", s, false, "Opcional: reduz atualizacoes de criaturas passivas distantes. Pode alterar o comportamento da IA.");
        throttleDistance = cfg.getInt("throttleDistance", s, 48, 16, 128, "Distancia de seguranca em relacao a jogadores.");
        throttleInterval = cfg.getInt("throttleInterval", s, 2, 2, 8, "Atualiza a criatura uma vez a cada N ticks.");
        itemLimit = cfg.getInt("itemLimit", s, 0, 0, 5000, "Limite opcional de itens no chao por mundo. Zero desativa a remocao.");
        if (cfg.hasChanged()) cfg.save();
    }

    public static void saveAll() {
        if (cfg == null) return;
        cfg.get("client", "adaptive", true).set(adaptive);
        cfg.get("client", "targetFps", 40).set(targetFps);
        cfg.get("client", "sampleTicks", 60).set(sampleTicks);
        cfg.get("client", "minRenderDistance", 3).set(minRenderDistance);
        cfg.get("client", "entityCull", true).set(entityCull);
        cfg.get("client", "cullDistance", 40).set(cullDistance);
        cfg.get("client", "baseTweaks", true).set(baseTweaks);
        cfg.get("client", "tweaksApplied", false).set(tweaksApplied);
        cfg.get("server", "serverThrottle", false).set(serverThrottle);
        cfg.get("server", "throttleDistance", 48).set(throttleDistance);
        cfg.get("server", "throttleInterval", 2).set(throttleInterval);
        cfg.get("server", "itemLimit", 0).set(itemLimit);
        cfg.save();
    }

    public static void markApplied() {
        tweaksApplied = true;
        if (cfg != null) {
            cfg.get("client", "tweaksApplied", false).set(true);
            cfg.save();
        }
    }
}
